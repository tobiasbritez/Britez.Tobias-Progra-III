"use strict";

/* ==========================================================
   ui.js - Utilidades de interfaz y validación compartidas
   por todas las páginas.
   ========================================================== */

const COLOR_HEX = /^#[0-9A-Fa-f]{6}$/;


/* ---------- Validaciones ---------- */

/** Valida un ID obligatorio (búsquedas). Devuelve un texto de error o null. */
function validarId(valor) {
  const texto = String(valor).trim();
  if (texto === "") return "Ingresá el ID del automóvil.";
  const numero = Number(texto);
  if (!Number.isInteger(numero) || numero <= 0) {
    return "El ID debe ser un número entero mayor que cero.";
  }
  return null;
}

/**
 * Valida los datos de un auto. El ID es opcional: solo se controla si viene completo.
 * Todos los valores llegan como texto (tal cual salen del formulario).
 * Devuelve un arreglo de errores; vacío si todo está bien.
 */
function validarAuto({ id = "", marca, precio, color }) {
  const errores = [];

  if (String(id).trim() !== "") {
    const numero = Number(id);
    if (!Number.isInteger(numero) || numero <= 0) {
      errores.push("El ID debe ser un número entero mayor que cero.");
    }
  }

  if (!String(marca).trim()) {
    errores.push("La marca es obligatoria.");
  }

  if (String(precio).trim() === "") {
    errores.push("El precio es obligatorio.");
  } else if (!(Number(precio) > 0)) {
    errores.push("El precio debe ser mayor que cero.");
  }

  if (!String(color).trim()) {
    errores.push("El color es obligatorio.");
  } else if (!COLOR_HEX.test(String(color).trim())) {
    errores.push("El color debe estar en formato hexadecimal, por ejemplo #FF0000.");
  }

  return errores;
}


/* ---------- Mensajes ---------- */

/**
 * Muestra un mensaje en el contenedor indicado.
 * tipo: "exito" | "error" | "info".
 * contenido: texto, o arreglo de textos (se muestra como lista).
 */
function mostrarMensaje(contenedor, tipo, contenido) {
  const iconos = { exito: "✓", error: "✗", info: "" };

  const caja = document.createElement("div");
  caja.className = `mensaje mensaje-${tipo}`;
  caja.setAttribute("role", tipo === "error" ? "alert" : "status");

  if (iconos[tipo]) {
    const icono = document.createElement("span");
    icono.className = "mensaje-icono";
    icono.setAttribute("aria-hidden", "true");
    icono.textContent = iconos[tipo];
    caja.append(icono);
  }

  const cuerpo = document.createElement("div");
  if (Array.isArray(contenido)) {
    const titulo = document.createElement("p");
    titulo.textContent = "Revisá los datos ingresados:";
    const lista = document.createElement("ul");
    for (const texto of contenido) {
      const item = document.createElement("li");
      item.textContent = texto;
      lista.append(item);
    }
    cuerpo.append(titulo, lista);
  } else {
    const parrafo = document.createElement("p");
    parrafo.textContent = contenido;
    cuerpo.append(parrafo);
  }
  caja.append(cuerpo);

  contenedor.replaceChildren(caja);
}

function limpiarMensaje(contenedor) {
  contenedor.replaceChildren();
}


/* ---------- Botones ---------- */

/** Deshabilita el botón y cambia su texto mientras se espera la respuesta. */
function establecerCargando(boton, cargando, textoCargando = "Procesando…") {
  if (cargando) {
    boton.dataset.textoOriginal = boton.textContent;
    boton.textContent = textoCargando;
    boton.disabled = true;
    boton.setAttribute("aria-busy", "true");
  } else {
    if (boton.dataset.textoOriginal) boton.textContent = boton.dataset.textoOriginal;
    boton.disabled = false;
    boton.removeAttribute("aria-busy");
  }
}


/* ---------- Color ---------- */

/** Mantiene sincronizados el selector de color y el campo de texto hexadecimal. */
function enlazarColor(selector, texto) {
  selector.addEventListener("input", () => {
    texto.value = selector.value.toUpperCase();
  });
  texto.addEventListener("input", () => {
    const valor = texto.value.trim();
    if (COLOR_HEX.test(valor)) selector.value = valor.toLowerCase();
  });
}

function establecerColor(selector, texto, hex) {
  texto.value = hex ?? "";
  if (COLOR_HEX.test(hex ?? "")) selector.value = hex.toLowerCase();
}

/** Crea el elemento "cuadradito de color + código". */
function crearMuestraColor(hex) {
  const contenedor = document.createElement("span");
  contenedor.className = "color";

  const muestra = document.createElement("span");
  muestra.className = "color-muestra";
  muestra.setAttribute("aria-hidden", "true");
  if (COLOR_HEX.test(hex ?? "")) muestra.style.backgroundColor = hex;

  const codigo = document.createElement("code");
  codigo.textContent = hex ?? "";

  contenedor.append(muestra, codigo);
  return contenedor;
}


/* ---------- Tabla de autos ---------- */

function formatearPrecio(valor) {
  const numero = Number(valor);
  return Number.isFinite(numero) ? numero.toLocaleString("es-AR") : String(valor ?? "");
}

function agregarCelda(fila, texto, clase = "") {
  const celda = fila.insertCell();
  celda.textContent = texto;
  if (clase) celda.className = clase;
  return celda;
}

/** Arma la tabla ID / Marca / Precio / Color para una lista de autos. */
function crearTablaAutos(autos, etiqueta) {
  const contenedor = document.createElement("div");
  contenedor.className = "tabla-contenedor";

  const tabla = document.createElement("table");
  tabla.setAttribute("aria-label", etiqueta);

  const columnas = [
    { titulo: "ID", clase: "num" },
    { titulo: "Marca", clase: "" },
    { titulo: "Precio", clase: "num" },
    { titulo: "Color", clase: "" },
  ];
  const filaTitulos = tabla.createTHead().insertRow();
  for (const columna of columnas) {
    const th = document.createElement("th");
    th.scope = "col";
    th.textContent = columna.titulo;
    if (columna.clase) th.className = columna.clase;
    filaTitulos.append(th);
  }

  const cuerpo = tabla.createTBody();
  for (const auto of autos) {
    const fila = cuerpo.insertRow();
    agregarCelda(fila, auto.id, "num");
    agregarCelda(fila, auto.marca);
    agregarCelda(fila, formatearPrecio(auto.precio), "num");
    fila.insertCell().append(crearMuestraColor(auto.color));
  }

  contenedor.append(tabla);
  return contenedor;
}


/* ---------- Diálogo de confirmación ---------- */

/**
 * Muestra un diálogo modal y devuelve una promesa:
 * true si el usuario confirma, false si cancela o presiona Esc.
 */
function confirmar({ titulo, texto, textoConfirmar, peligro = false }) {
  return new Promise((resolver) => {
    const dialogo = document.createElement("dialog");
    dialogo.className = "dialogo";
    dialogo.setAttribute("aria-labelledby", "dialogo-titulo");

    const encabezado = document.createElement("h2");
    encabezado.id = "dialogo-titulo";
    encabezado.textContent = titulo;

    const parrafo = document.createElement("p");
    parrafo.textContent = texto;

    const formulario = document.createElement("form");
    formulario.method = "dialog";
    formulario.className = "acciones";

    const cancelar = document.createElement("button");
    cancelar.type = "submit";
    cancelar.value = "cancelar";
    cancelar.className = "boton boton-secundario";
    cancelar.textContent = "Cancelar";

    const aceptar = document.createElement("button");
    aceptar.type = "submit";
    aceptar.value = "confirmar";
    aceptar.className = `boton ${peligro ? "boton-peligro" : "boton-primario"}`;
    aceptar.textContent = textoConfirmar;

    formulario.append(cancelar, aceptar);
    dialogo.append(encabezado, parrafo, formulario);

    dialogo.addEventListener("close", () => {
      const aceptado = dialogo.returnValue === "confirmar";
      dialogo.remove();
      resolver(aceptado);
    });

    document.body.append(dialogo);
    dialogo.showModal();
    cancelar.focus();
  });
}
