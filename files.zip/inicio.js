"use strict";

/* inicio.js - Muestra si la API está respondiendo.
   Como el servidor gratuito se "duerme" tras un rato sin uso, esta
   comprobación también sirve para despertarlo antes de operar. */

const estadoPunto = document.getElementById("estado-punto");
const estadoTexto = document.getElementById("estado-texto");

async function actualizarEstado() {
  estadoTexto.textContent =
    "Conectando con el servidor… si estaba inactivo puede tardar hasta un minuto.";

  const enLinea = await comprobarServidor();

  estadoPunto.classList.add(enLinea ? "punto-ok" : "punto-error");
  estadoTexto.textContent = enLinea
    ? "Servidor en línea"
    : "No se pudo conectar con el servidor. Recargá la página para reintentar.";
}

actualizarEstado();
