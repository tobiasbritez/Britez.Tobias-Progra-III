"use strict";

/* modificar.js - Buscar un auto, editar sus datos y confirmar el cambio. */

const formBuscar = document.getElementById("form-buscar");
const campoBuscarId = document.getElementById("buscar-id");
const botonBuscar = document.getElementById("boton-buscar");
const areaMensaje = document.getElementById("mensaje");

const panelEdicion = document.getElementById("panel-edicion");
const formEdicion = document.getElementById("form-edicion");
const campoId = document.getElementById("edicion-id");
const campoMarca = document.getElementById("edicion-marca");
const campoPrecio = document.getElementById("edicion-precio");
const selectorColor = document.getElementById("color-selector");
const textoColor = document.getElementById("color-texto");
const botonGuardar = document.getElementById("boton-guardar");
const botonCancelar = document.getElementById("boton-cancelar");

let autoActual = null;

enlazarColor(selectorColor, textoColor);


/* ---------- Panel de edición ---------- */

function mostrarEdicion(auto) {
  autoActual = auto;
  campoId.value = auto.id;
  campoMarca.value = auto.marca;
  campoPrecio.value = auto.precio;
  establecerColor(selectorColor, textoColor, auto.color);
  panelEdicion.hidden = false;
  campoMarca.focus();
}

function ocultarEdicion() {
  autoActual = null;
  formEdicion.reset();
  panelEdicion.hidden = true;
}


/* ---------- Paso 1: buscar ---------- */

async function buscar(evento) {
  evento.preventDefault();
  ocultarEdicion();

  const errorId = validarId(campoBuscarId.value);
  if (errorId) {
    mostrarMensaje(areaMensaje, "error", errorId);
    return;
  }

  establecerCargando(botonBuscar, true, "Buscando…");
  limpiarMensaje(areaMensaje);

  try {
    mostrarEdicion(await obtenerAuto(campoBuscarId.value.trim()));
  } catch (error) {
    mostrarMensaje(areaMensaje, "error", error.message);
  } finally {
    establecerCargando(botonBuscar, false);
  }
}


/* ---------- Paso 2: guardar ---------- */

async function guardar(evento) {
  evento.preventDefault();
  if (!autoActual) return;

  const datos = {
    marca: campoMarca.value.trim(),
    precio: campoPrecio.value,
    color: textoColor.value.trim(),
  };

  const errores = validarAuto(datos);
  if (errores.length > 0) {
    mostrarMensaje(areaMensaje, "error", errores);
    return;
  }

  const confirmado = await confirmar({
    titulo: "Guardar cambios",
    texto: `Se van a modificar los datos del automóvil con ID ${autoActual.id}.`,
    textoConfirmar: "Guardar cambios",
  });
  if (!confirmado) return;

  establecerCargando(botonGuardar, true, "Guardando…");
  limpiarMensaje(areaMensaje);

  try {
    await modificarAuto(autoActual.id, {
      marca: datos.marca,
      precio: Number(datos.precio),
      color: datos.color,
    });
    mostrarMensaje(areaMensaje, "exito", "Automóvil modificado correctamente.");
  } catch (error) {
    mostrarMensaje(areaMensaje, "error", error.message);
  } finally {
    establecerCargando(botonGuardar, false);
  }
}


formBuscar.addEventListener("submit", buscar);
formEdicion.addEventListener("submit", guardar);
botonCancelar.addEventListener("click", () => {
  ocultarEdicion();
  limpiarMensaje(areaMensaje);
});
